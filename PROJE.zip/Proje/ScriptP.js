


const cartList = document.getElementById("sepet");

class Shopping {
    constructor(price, image) {
        

        this.price = price;
        this.image = image;
    }
}


class UI {

    addToCard(shopping) {

        const listItem = document.createElement("div");
        listItem.classList = "list-item";

        listItem.innerHTML =
            `
             <div class="row align-items-center text-white-50">
                 <div class="col-md-4">
                     <div class="price">Ürün Id:${shopping.image}</div>
                 </div>         
                <div class="col-md-4">
                  <div class="price">Ürün Fiyat:${shopping.price}</div>
                </div>
                <div class="col-md-3">
                     <button class="btn btn-delete">
                         <i class="fa fa-trash text-danger"></i>
                     </button>
                </div>
              </div>
            `
        cartList.appendChild(listItem);
    }

    removeCart(){
        let btnRemove = document.getElementsByClassName("btn-delete");

        for (let i = 0; i < btnRemove.length; i++) {
            btnRemove[i].addEventListener("click", function(){
                this.parentElement.parentElement.parentElement.remove();
            })
            
        }
    }

}



function AddAndDelete() {


    let price = document.getElementById("price").textContent;
    let image = document.getElementById("ID").textContent;

    
    let shopping = new Shopping(price, image);

    let uı = new UI();
    uı.addToCard(shopping);  
    uı.removeCart();

    window.alert("Ürün sepete eklendi!");

}


